package com.example.week10_lab_n01619143;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week10LabN01619143ApplicationTests {

    @Test
    void contextLoads() {
    }

}
